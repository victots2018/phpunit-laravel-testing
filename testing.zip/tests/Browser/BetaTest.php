<?php

namespace Tests\Browser;

use Tests\DuskTestCase;
use Laravel\Dusk\Browser;
use Illuminate\Foundation\Testing\DatabaseMigrations;

class BetaTest extends DuskTestCase
{
    /**
     * A basic test example.
     *
     * @return void
     */
    public function testDisplaysBeta()
    {
        $this->browse(function ($browser) {
           $browser->visit('/beta')
                   ->assertSee('Beta')
                   ->assertDontSee('Alpha');
       });
    }

    public function testClickNextForAlpha()
    {
        $this->browse(function ($browser) {
            $browser->visit('/beta')
             ->press('Back')
             ->assertPathIs('/alpha');
        });
    }
}
