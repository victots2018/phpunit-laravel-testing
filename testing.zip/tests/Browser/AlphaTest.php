<?php

namespace Tests\Browser;

use Tests\DuskTestCase;
use Laravel\Dusk\Browser;
use Illuminate\Foundation\Testing\DatabaseMigrations;

class ExampleTest extends DuskTestCase
{
    /**
     * A basic browser test example.
     *
     * @return void
     */
    public function testDisplaysAlpha()
    {
        $this->browse(function ($browser) {
           $browser->visit('/alpha')
                   ->assertSee('This is the Alpha page.');
       });
    }

    public function testClickNextForBeta()
    {
        $this->browse(function ($browser) {
            $browser->visit('/alpha')
             ->press('Next')
             ->assertPathIs('/beta');
        });
    }
}
