<!DOCTYPE html>
<html>
    <head>
        <title>Beta</title>
    </head>
    <body>
        <p>This is the Beta page.</p>
        <button><a href="/alpha">Back</a></button>
    </body>
</html>